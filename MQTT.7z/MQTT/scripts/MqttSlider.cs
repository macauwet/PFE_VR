using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

public class MqttSlider : MonoBehaviour
{
    protected CoVRController _covrCtrl;
    protected MqttClient _client;
    public string buttonName = "Slider";
    private bool autoZero = false;
    private bool newValue = false;
    public UnityEvent<float> buttonEvent;
    public float value=0;

    public string ButtonMqttPath => $"covr/button/{buttonName}";
    // Start is called before the first frame update
    void Start()
    {
        if (buttonName == "None")
        {
            buttonName = DateTime.Today.ToShortDateString();
        }
        _covrCtrl = GameObject.FindGameObjectWithTag("MqttManager").GetComponent<CoVRController>();
        _client = _covrCtrl.Client;
        _client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;
        if (_client != null)
        {
            _client.Subscribe(new string[] { ButtonMqttPath }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE });
        }
    }

    private void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
    {
        string msg = Encoding.UTF8.GetString(e.Message);
        float oldvalue = value;
        if (e.Topic == ButtonMqttPath)
        {
            
            float.TryParse(msg, out value);
            
            newValue = (oldvalue != value);


        }
        
    }


    // Update is called once per frame
    void Update()
    {
        if (newValue)
        {
            buttonEvent?.Invoke(value);
            Debug.Log($"{buttonName} message recive: {value}");
            if (autoZero)
            {
                _client.Publish(ButtonMqttPath, Encoding.UTF8.GetBytes("0"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            }
        }
    }
}
