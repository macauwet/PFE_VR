using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

public class MqttButton : MonoBehaviour
{
    protected CoVRController _covrCtrl;
    protected MqttClient _client;
    public string buttonName = "None";
    private bool active = false;
    public UnityEvent buttonEvent;
    public string ButtonMqttPath => $"covr/button/{buttonName}";
    // Start is called before the first frame update
    void Start()
    {
        if (buttonName=="None")
        {
            buttonName=DateTime.Today.ToShortDateString();
        }
        _covrCtrl = GameObject.FindGameObjectWithTag("MqttManager").GetComponent<CoVRController>();
        _client = _covrCtrl.Client;
        _client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;
        if (_client != null)
        {
            _client.Subscribe(new string[] { ButtonMqttPath }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE });
        }
    }

    private void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
    {
        string msg = Encoding.UTF8.GetString(e.Message);
        if (e.Topic == ButtonMqttPath)
        {
            int buttonInt = 0;
            int.TryParse(msg, out buttonInt);
            active = buttonInt != 0;
            Debug.Log($"{buttonName} message recive: {active}");
            

            
        }
    }
    

    // Update is called once per frame
    void Update()
    {
        if (active)
        {
            buttonEvent?.Invoke();
            active = false;
            _client.Publish(ButtonMqttPath, Encoding.UTF8.GetBytes("0"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
        }
    }
}
