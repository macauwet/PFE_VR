﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

/**
 * @file AxisSimulator.cs
 *
 * @brief MQTT client to simulate one axis
 *
 * @author Philippe Gauthier
 * Contact: philippe.gauthier@sorbonne-universite.fr
 *
 */



public class AxisSimulator : MonoBehaviour
{
    public CoVRController _covrCtrl;
    private MqttClient _client;

    public const Int32 _minBound = 0;
    public const Int32 _maxBound = 6000000;
    public Int32 _axisMaxBound = 6000000;
    public static List<string> OpReady = new List<string>() { "Ready to switch on", "Switch on disabled" };
    public static List<string> StateReady = new List<string>() { "0xc231", "0xd231", "0xc631", "0xd250" };

    public string _mqqtPath = "covr/y2";
    [Tooltip("Position from Mqqt is multiplied by this vector to the forwarded local position")]
    public Vector3 _posToUnityPosition = new Vector3(1, 0, 0);

    protected Rigidbody _rigidBody;

    [Header("State")]
    public string _operating_state;
    public string _error_code;
    public string _status;

    [Header("Profile")]
    public Int32 _max_profile_velocity;
    public Int32 _profile_velocity;
    public Int32 _profile_acceleration;
    public Int32 _profile_deceleration;

    //Vector3 _targetVel = new Vector3();
    Vector3 _refVel = Vector3.zero; 

    [Header("Position Profile")]
    public bool _PPEnabled = false;
    public Int32 _pp_target;


    [Header("Velocity Profile")]
    public bool _VPEnabled = false;
    public Int32 _vp_target;


    [Header("UI")]
    public int _guiXOffset = 0;
    public int _guiYOffset = 0;

    protected GUIStyle _guiStyleError = new GUIStyle();
    protected GUIStyle _guiStyleNorm = new GUIStyle();
    protected GUIStyle _guiStyleLeft = new GUIStyle();

    public UnityEvent OnConnected;
    public UnityEvent OnDisconnected;
    public Int32 _actual_torque;
    public Int32 _actual_current;
    public Int32 _actual_position;
    public Int32 _actual_velocity;

    public Int32 _target_absolute;
    private bool _target_absolute_on = false;
    

    // Use this for initialization
    void Start()
    {
        _operating_state = "Ready to switch on";
        _error_code = "";
        _status = "0xe288";
        _rigidBody = GetComponent<Rigidbody>();

        _guiStyleError.fontStyle = FontStyle.Bold;
        _guiStyleLeft.alignment = TextAnchor.UpperLeft;
        // create client instance 
        if (_covrCtrl != null)
        {

            _covrCtrl.onConnected += AxisOnConnected;
            _covrCtrl.onDisconnected += AxisOnDisconnected;
        }
        else
        {
            Debug.Log($"AxisSimulator {_mqqtPath} covrCtrl is null");
        }
    }

    private void AxisOnDisconnected()
    {
        OnDisconnected.Invoke();
    }
    private void AxisOnConnected()
    {
        _client = _covrCtrl.Client;       
       
        if (_client != null)
        {
            _client.Subscribe(new string[] { $"{_mqqtPath}/clear_error" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE }); // QoS2
            _client.Subscribe(new string[] { $"{_mqqtPath}/fault_reset" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE }); // QoS2
            _client.Subscribe(new string[] { $"{_mqqtPath}/homing" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE }); // QoS2
            _client.Subscribe(new string[] { $"{_mqqtPath}/profile_velocity/update" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE }); // QoS2

            // position control
            _client.Subscribe(new string[] { $"{_mqqtPath}/pp/update" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE }); // QoS0
            _client.Subscribe(new string[] { $"{_mqqtPath}/pp/enable" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE }); // QoS2
            _client.Subscribe(new string[] { $"{_mqqtPath}/pp/disable" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });// QoS2

            _client.Subscribe(new string[] { $"{_mqqtPath}/pp/target_absolute" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE }); // QoS0
            _client.Subscribe(new string[] { $"{_mqqtPath}/pp/target_relative" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE }); // QoS0

            // velocity control
            _client.Subscribe(new string[] { $"{_mqqtPath}/vp/update" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE }); // QoS0
            _client.Subscribe(new string[] { $"{_mqqtPath}/vp/enable" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE }); // QoS2
            _client.Subscribe(new string[] { $"{_mqqtPath}/vp/disable" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });// QoS2

            

            _client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;
            Debug.Log("Axis '" + _mqqtPath + "' started");
            OnConnected.Invoke();
        }       
    }


    void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
    {
        string msg = Encoding.UTF8.GetString(e.Message);
        if (e.Topic == $"{_mqqtPath}/pp/target_absolute")
            move_absolute(Int32.Parse(msg));
        else if (e.Topic == $"{_mqqtPath}/profile_velocity/update")
            profile_velocity_update(Int32.Parse(msg));
        else if (!_target_absolute_on)
        {
            if (!_VPEnabled)
            {
                if (e.Topic == $"{_mqqtPath}/pp/enable")
                    SetPPEnable(true);
                else if (e.Topic == $"{_mqqtPath}/pp/disable")
                    SetPPEnable(false); 
                if (_PPEnabled && e.Topic == $"{_mqqtPath}/pp/update")
                    _pp_target = Int32.Parse(msg);
            }
            if (!_PPEnabled)
            {
                if (e.Topic == $"{_mqqtPath}/vp/enable")
                    SetVPEnable(true);
                else if (e.Topic == $"{_mqqtPath}/vp/disable")
                    SetVPEnable(false);
                if (_VPEnabled && e.Topic == $"{_mqqtPath}/vp/update")
                    _vp_target = Int32.Parse(msg);
            }
        }
        


        //else Debug.Log("Received: " + Encoding.UTF8.GetString(e.Message));
    }

    private void SetPPEnable(bool on)
    {
        _PPEnabled = on;
        if (_PPEnabled)
        {
            _operating_state = "Operation enabled";
            _status = "0xd637";
        }
        else
        {
            _operating_state = "Ready to switch on";
            _status = "0xc231";
        }
    }

    private void SetVPEnable(bool on)
    {
        _VPEnabled = on;
        if (_VPEnabled)
        {
            _operating_state = "Operation enabled";
            _status = "0x9637";
        }
        else
        {
            _operating_state = "Ready to switch on";
            _status = "0xd231";
        }
    }

    private void profile_velocity_update(int v)
    {
        float value = (float)v;
        float max_value = (float)_max_profile_velocity;
        _profile_velocity = (Int32)Mathf.Clamp(value,1000f, max_value);
        _profile_acceleration = _profile_velocity / 2;
        _profile_deceleration = _profile_acceleration;
    }

    private void move_absolute(Int32 p)
    {
        if (_PPEnabled || _VPEnabled)
        {
            Debug.Log($"{_mqqtPath} can't move_absolute while position or velocity profile is on");
            return; 
        }
        if (!_target_absolute_on || Math.Abs(_actual_velocity) < 1000)
        {
            _operating_state = "Operation enabled";
            _status = "0x8237";
            Debug.Log($"{_mqqtPath} move_absolute: {p}");
            p = Mathf.Clamp(p, 0, _axisMaxBound);
            _target_absolute = p;
            _target_absolute_on = true;
        }
    }

    void OnGUI()
    {
        //const int butW = 90, butH = 20;
        //GUI.Label(new Rect(_guiXOffset, _guiYOffset, 40, 20), _mqqtPath, _guiStyleNorm);
        //GUI.Label(new Rect(_guiXOffset + 40, _guiYOffset, 80, 20), _status, _guiStyleNorm);
        //GUI.Label(new Rect(_guiXOffset + 90, _guiYOffset, 100, 20), _error_code, _guiStyleError);
        //GUI.Label(new Rect(_guiXOffset + 140, _guiYOffset, 0, 20), _operating_state, _guiStyleNorm);

    }

    private Int32 Vec3toMmeter(Vector3 p)
    {
        return (Int32)(Vector3.Dot(p, _posToUnityPosition) * 1e6f);
    }


    // runs every 20ms
    private void FixedUpdate()
    {
        _actual_position = Vec3toMmeter(transform.localPosition);
        _actual_velocity = Vec3toMmeter(_rigidBody.velocity);
        if (_target_absolute_on)
        {
            moveToTarget(_target_absolute);
            // if position close enough to target stop
            if (Math.Abs(_target_absolute-_actual_position)<1e4)
            {
                StopTargetAbsolute();
            }
        }else if (_PPEnabled)
        {
            // if it goes out of bounds don't move
            if ( _pp_target < 0 || _pp_target > _maxBound)
                return;
            
            moveToTarget(_pp_target);
        }
        else if (_VPEnabled)
        {
            // if it goes out of bounds don't move
            if (_vp_target < 0 && _actual_position < 0 ||_vp_target > 0 && _actual_position > _maxBound)
                return;
            moveBy(_vp_target);
        }
    }

    private void moveToTarget(Int32 target)
    {        
        float max_speed = _profile_velocity * 1e-6f;
        float smoothTime = (float)(_profile_velocity) / _profile_acceleration * .5f;
        float p = target * 1e-6f;

        Vector3 targetP = transform.parent.position + p * _posToUnityPosition;
        Vector3 movePosition = Vector3.SmoothDamp(_rigidBody.transform.position, targetP, ref _refVel, smoothTime, max_speed);

        _rigidBody.MovePosition(movePosition);
    }

    private void moveBy(Int32 targetVelocty)
    {
        float max_speed = _profile_velocity * 1e-6f;
        float smoothTime = (float)(_profile_velocity) / _profile_acceleration * .5f;
        float v = targetVelocty * 1e-6f;

        Vector3 targetP = transform.position + v * _posToUnityPosition;
        Vector3 movePosition = Vector3.SmoothDamp(_rigidBody.transform.position, targetP, ref _refVel, smoothTime, max_speed);

        _rigidBody.MovePosition(movePosition);
    }

    private void StopTargetAbsolute()
    {
        _target_absolute_on = false;
        _operating_state = "Ready to switch on";
        _status = "0xc231";
        Debug.Log($"{_mqqtPath} target reached: {_actual_position}");
    }

    void Update()
    {
        if (_client != null)
        {
            _client.Publish($"{_mqqtPath}/actual_torque", Encoding.UTF8.GetBytes($"{_actual_torque}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/actual_current", Encoding.UTF8.GetBytes($"{_actual_current}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/actual_position", Encoding.UTF8.GetBytes($"{_actual_position}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/actual_velocity", Encoding.UTF8.GetBytes($"{_actual_velocity}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/max_profile_velocity", Encoding.UTF8.GetBytes($"{_max_profile_velocity}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/profile_acceleration", Encoding.UTF8.GetBytes($"{_profile_acceleration}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/profile_deceleration", Encoding.UTF8.GetBytes($"{_profile_deceleration}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/profile_velocity", Encoding.UTF8.GetBytes($"{_profile_velocity}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/status", Encoding.UTF8.GetBytes($"{_status}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/operating_state", Encoding.UTF8.GetBytes($"{_operating_state}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/error_code", Encoding.UTF8.GetBytes($"{_error_code}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/pp/active", Encoding.UTF8.GetBytes($"{(_PPEnabled ? 1 : 0)}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/vp/active", Encoding.UTF8.GetBytes($"{(_VPEnabled ? 1 : 0)}"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
            _client.Publish($"{_mqqtPath}/csp/active", Encoding.UTF8.GetBytes("0"), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false); // QoS0
        }
    }
}
