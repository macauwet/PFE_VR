# CoVR Simulator SetUp
## Description
The Covr Simulator is made for Covr deplacement testing in local without the covr hadrware platform. It's using a Local MQTT broker that can be used to receve other input from other devices.

Be carefull when apply the code tested with this simulator because the behaviour of the real platform can be different. 
If Someone is in the Covr deplacement erea be ready at all time to push emergency stop button.

## Set Up
### Mosquitto MQTT Broker
First Prepare the environmment by installing the MQTT broker service on your computer.

[Mosquitto](https://mosquitto.org/) MQTT broker is easy to install and operate.  

When installed look in your computer service list to see if mosquitto appear as illustrated in the following capture.

<img src="image/CoVRSimilatorServiceListMosquittoBroker.png" alt="" style="margin: 0 auto; display: block;" />

Check is the service is Running. When douvle click on the service a properties window appear where you can start the service.


<img src="image/CoVRSimilatorServicePropertiesMosquittoBroker.png" alt="" style="margin: 0 auto; display: block;" />


### MQTT Explorer

We recommend to also install [MQTT Explorer](https://mqtt-explorer.com/) as he can help you see the message passing through the MQTT broker.

When installed use the parameters illustrated in the folling capture then click connect to start checking the Broker message trafic.

<img src="image/CoVRSimilatorMQTTexplorerParameters.png" alt="" style="margin: 0 auto; display: block;" />
<img src="image/CoVRSimilatorMQTTexplorerConnected.png" alt="" style="margin: 0 auto; display: block;" />

### Unity Scene
The simulator in made of two objects, One for each Covr's axis, that contains among their componant the AxisSimulator script. 
Thoses objects need to be present in the persistent scene as children of the World/Structure/XYRobot/offsetX object as illustrated in the following capture.

<img src="image/CoVRSimilatorHierarchy.png" alt="" style="margin: 0 auto; display: block;" />

You need to verify in the inspector that the AxisSimulation component of the two object are proprely configured as showen in the two following captures.

 <div style="display: flex;flex-shrink: 0; align-items: center;">
  <img src="image/CoVRSimilatorInspectorCoVRSimObjectX.png" alt="Your Image" style="margin:15px" />
  <img src="image/CoVRSimilatorInspectorCoVRSimObjectY.png" alt="Your Image" style="margin:15px" />
</div>


In order to make it work you need to change the MQTTManager, MQTTManager/ACX and MQTTManager/ACY parameter to subscribe and publish message to the simulator by the local broker.
 

 <div style="display: flex;flex-shrink: 0; align-items: center;">
  <img src="image/CoVRSimilatorInspectorMQTTManagerDirect.png" alt="Your Image" style="margin:15px" />
  <img src="image/CoVRSimilatorInspectorMQTTManager.png" alt="Your Image" style="margin:15px" />
</div>

 <div style="display: flex;flex-shrink: 0; align-items: center;">
  <img src="image/CoVRSimilatorInspectorACXdirect.png" alt="Your Image" style="margin:15px" />
  <img src="image/CoVRSimilatorInspectorACX.png" alt="Your Image" style="margin:15px" />
</div>

 <div style="display: flex;flex-shrink: 0; align-items: center;">
  <img src="image/CoVRSimilatorInspectorACYdirect.png" alt="Your Image" style="margin:15px" />
  <img src="image/CoVRSimilatorInspectorACY.png" alt="Your Image" style="margin:15px" />
</div>

### Project Start 
If you whant the simulator to work activate the World/Structure/XYRobot/offsetX/CoVRSimulator object and choose the right scripts configurations for MQTTManager, MQTTManager/ACX and MQTTManager/ACY. It's need to be set before play mode.

To revert to direct covr configuration just deactivate the the World/Structure/XYRobot/offsetX/CoVRSimulator object and change to the left configuration of the MQTTManager, MQTTManager/ACX and MQTTManager/ACY.





